import java.util.Scanner;
import java.math.BigInteger;

class Ex3_12 {
	static BigInteger gcd(BigInteger a, BigInteger b) {
		BigInteger u = BigInteger.ONE;
		BigInteger g = a;
		BigInteger x = BigInteger.ZERO;
		BigInteger y = b;
		BigInteger s = BigInteger.ZERO;
		BigInteger v = BigInteger.ZERO;
		
		if(y.equals(BigInteger.ZERO)) {
			return y;
		}
		
		while(!y.equals(new BigInteger("0"))) {
			BigInteger q = g.divide(y);
			BigInteger t = g.mod(y);
			
			s = u.subtract(q.multiply(x));
			
			u = x;
			g = y;
			x = s;
			y = t;
		}
		return g;
	}
	
	static BigInteger PollardP1(BigInteger N) {
		BigInteger a = new BigInteger("2");
		for (BigInteger j = new BigInteger("2"); j.compareTo(N) < 1; j = j.add(BigInteger.ONE)) {
			a = a.modPow(j, N);
			BigInteger d = gcd(a.subtract(BigInteger.ONE), N);
			if (d.compareTo(BigInteger.ONE) > 0 && d.compareTo(N) < 0) {
				return d;
			}
		}
		return null;
	}
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("N = ");
		BigInteger N = new BigInteger(scan.nextLine());
		BigInteger P = PollardP1(N);
		if (P == null && (N.mod(new BigInteger("2"))).compareTo(BigInteger.ONE)==0) {
			System.out.println(N);
			System.out.println("1");
			return;
		}
		while (P != null) {
			System.out.println(P);
			N = N.divide(P);
			P = PollardP1(N);
		}
		if ((N.mod(new BigInteger("2"))).compareTo(BigInteger.ONE)==0) {
			System.out.println(N);
			return;
		}
		while ((N.mod(new BigInteger("2"))).compareTo(BigInteger.ONE)!=0) {
			System.out.println("2");
			N = N.divide(new BigInteger("2"));
		}
	}
}
