import java.util.Scanner;
import java.math.BigInteger;
import java.lang.IllegalArgumentException;

class GoldwasserMicali {
	static int legendre(BigInteger a, BigInteger p) {
		BigInteger temp = a.modPow((p.subtract(BigInteger.ONE)).divide(new BigInteger("2")), p);
		if (temp.equals(p.subtract(BigInteger.ONE))) temp = new BigInteger("-1");
		return temp.intValue();
	}
	
	//returns [(N=pq), a]
	public static BigInteger[] createKey(BigInteger p, BigInteger q) {
		BigInteger N = p.multiply(q);
		BigInteger a = null;
		for (BigInteger i = N.subtract(BigInteger.ONE); i.compareTo(new BigInteger("2")) > 0;i = i.subtract(BigInteger.ONE)) {
			if (legendre(i, p) == -1 && legendre(i, q) == -1) {
				a = i;
				break;
			}
		}
		if (a == null) throw new IllegalArgumentException();
		return new BigInteger[] {N, a};
	}
	
	public static BigInteger encrypt(int m, BigInteger N, BigInteger a, BigInteger r) {
		BigInteger c = (r.pow(2)).mod(N);
		if (m==0) {
			return c;
		} else if (m==1) {
			return ((c.multiply(a)).mod(N));
		}
		throw new IllegalArgumentException();
	}
	
	public static int decrypt(BigInteger c, BigInteger p) {
		int l = legendre(c, p);
		if (l == 1) {
			return 0;
		} else if (l == -1) {
			return 1;
		}
		throw new IllegalArgumentException();
	}
}

class Ex3_41 {
	static BigInteger gcd(BigInteger a, BigInteger b) {
		BigInteger u = BigInteger.ONE;
		BigInteger g = a;
		BigInteger x = BigInteger.ZERO;
		BigInteger y = b;
		BigInteger s = BigInteger.ZERO;
		BigInteger v = BigInteger.ZERO;
		
		if(y.equals(BigInteger.ZERO)) {
			return y;
		}
		
		while(!y.equals(new BigInteger("0"))) {
			BigInteger q = g.divide(y);
			BigInteger t = g.mod(y);
			
			s = u.subtract(q.multiply(x));
			
			u = x;
			g = y;
			x = s;
			y = t;
		}
		return g;
	}
	
	static BigInteger pollardP1(BigInteger N) {
		BigInteger a = new BigInteger("2");
		for (BigInteger j = new BigInteger("2"); j.compareTo(N) < 1; j = j.add(BigInteger.ONE)) {
			a = a.modPow(j, N);
			BigInteger d = gcd(a.subtract(BigInteger.ONE), N);
			if (d.compareTo(BigInteger.ONE) > 0 && d.compareTo(N) < 0) {
				return d;
			}
		}
		return null;
	}
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("List unavailable as '!'");
		System.out.print("p = ");
		String p = scan.nextLine();
		System.out.print("q = ");
		String q = scan.nextLine();
		System.out.print("N = ");
		String N = scan.nextLine();
		System.out.print("a = ");
		String a = scan.nextLine();
		System.out.print("plaintext = ");
		String text = scan.nextLine();
		System.out.print("ciphertext = ");
		String cipher = scan.nextLine();
		
		if (!p.equals("!") && !q.equals("!") && text.equals("!") && cipher.equals("!")) {
			System.out.println("Key Creation:");
			BigInteger[] key = GoldwasserMicali.createKey(new BigInteger(p), new BigInteger(q));
			System.out.println("N = " + key[0] + "\na = " + key[1]);
		} else if (!N.equals("!") && !a.equals("!") && !text.equals("!") && cipher.equals("!")) {
			System.out.print("Encryption:\nr = ");
			BigInteger r = new BigInteger(scan.nextLine());
			System.out.println("ciphertext = " + GoldwasserMicali.encrypt((new BigInteger(text)).intValue(), new BigInteger(N), new BigInteger(a), r));
		} else if (!p.equals("!") && !q.equals("!") && text.equals("!") && !cipher.equals("!")) {
			System.out.println("Decryption:");
			System.out.println("plaintext = " + GoldwasserMicali.decrypt(new BigInteger(cipher), new BigInteger(p)));
		} else if (p.equals("!") && q.equals("!") && !N.equals("!") && text.equals("!") && !cipher.equals("!")) {
			System.out.println("Break:");
			BigInteger prime = pollardP1(new BigInteger(N));
			System.out.println("p = " + prime + "\nplaintext = " + GoldwasserMicali.decrypt(new BigInteger(cipher), prime));
		} else {
			System.out.println("Insufficient or excess information provided.");
		}
	}
}





